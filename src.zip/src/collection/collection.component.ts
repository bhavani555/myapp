import { Component } from '@angular/core';

@Component({
  selector: 'col',
  templateUrl: './collection.component.html'
  //styleUrls: ['./app.component.css']
})
export class CollectionComponent {



// collections:any[]=[
  
//   {id:"1",Title:"avenger", catagory:"robot",Author:"kjk",  Description:"5"},
//      {id:"1",Title:"avenger", catagory:"robot",Author:"kjk",  Description:"5"},
//        {id:"1",Title:"avenger", catagory:"robot",Author:"kjk",  Description:"5"},
//          {id:"1",Title:"avenger", catagory:"robot",Author:"kjk",  Description:"5"},
 
  
// ];


}
