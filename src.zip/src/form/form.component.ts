import { Component } from '@angular/core';

@Component({
  selector: 'fr',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css'],
  //styleUrls: ['./app.component.css']
})
export class FormComponent{
  
  

}
