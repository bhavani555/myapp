import { Component } from '@angular/core';

@Component({
  selector: 'bk',
  templateUrl: './book.component.html',
  //styleUrls: ['./form.component.css'],
  //styleUrls: ['./app.component.css']
})
export class BookComponent{
  
      books:any[]=[
  
   {id:"1",Title:"hjgj", catagory:"robot",Author:"kjk",  Description:"5"},
   {id:"2",Title:"avenger", catagory:"robot",Author:"kjk",  Description:"5"},
   {id:"3",Title:"avenger", catagory:"robot",Author:"kjk",  Description:"5"},
   {id:"4",Title:"avenger", catagory:"robot",Author:"kjk",  Description:"5"},
   {id:"5",Title:"avenger", catagory:"robot",Author:"kjk",  Description:"5"},
   {id:"6",Title:"avenger", catagory:"robot",Author:"kjk",  Description:"5"},
   {id:"7",Title:"avenger", catagory:"robot",Author:"kjk",  Description:"5"},
   
   
 
  
 ];

}
