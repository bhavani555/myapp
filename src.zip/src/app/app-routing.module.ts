import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LibraryComponent } from './../library/library.component';
import { CollectionComponent } from './../collection/collection.component';
import { FormComponent } from './../form/form.component';
import { BookComponent } from './../book/book.component';


const routes: Routes = [

    {path:'library',component:LibraryComponent},
  //{path:'movies',component:MovieComponent},
//{path:'',component:HomeComponent,pathMatch:'full'},
 // {path:'home',component:HomeComponent},
  {path:'collection',component:CollectionComponent},
  {path:'form',component:FormComponent},
  { path:'book',component:BookComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
